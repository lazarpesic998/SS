#include "../inc/assembler.h"
using namespace std;

//VARIABLES
int currentSymbolNumber = 0;
map <string, SymbolTableEntry> symbolTable;
int currentSectionNumber = 0;
int locationCounter = 0;
string currentSectionName = "UND";
SymbolTableEntry currentSection;


//FUNCTIONS
void setupAssembler(){
  SymbolTableEntry* newEntry = new SymbolTableEntry("UND",0,0,currentSymbolNumber++, false, false,{}, 0);
  symbolTable["UND"] = *newEntry;
}

void processLine(string currentLine){

  //trimming line
  string myLine = trimComments(currentLine);
  myLine = trim(myLine);
  if (currentLine.size() == 0) return;

  if (processDirective(currentLine)) return;
  //if(processInstruction(currentLine)) return;

}

bool processDirective(string currentLine){

  if(isGlobalDirective(currentLine)){processGlobalDirective(currentLine); return true;}
  if(isExtern(currentLine)){processExtern(currentLine); return true;}
  if(isSection(currentLine)){processSection(currentLine); return true;}
  return false;

}


bool isGlobalDirective(string currentLine){
    regex reg ("(.global)");
    smatch matches;

    while(std::regex_search(currentLine, matches, reg)){
        //std::cout << "Nadjena global direktiva  " << "\n";
        return matches.ready();
    }
    return false;

}

void processGlobalDirective(string currentLine){

  regex reg ("([_a-zA-Z][_a-zA-Z0-9]*)");
  smatch matches;

  while(std::regex_search(currentLine, matches, reg)){
    // Get the first match
      string currVar = matches.str(1);
  
      // Eliminate the previous match and create
      // a new string to search
      currentLine = matches.suffix().str();
      if(currVar == "global") continue;

      if(symbolTable.find(currVar) != symbolTable.end()) {
        cout<< "***ERROR!*** Symbol already defined!" << endl;
        exit(-1);
      }
      SymbolTableEntry newEntry = SymbolTableEntry(currVar, -1 ,-1,currentSymbolNumber++, true, false,{}, -1);
      symbolTable[currVar] = newEntry;
  }
  // printSymbolTable();
}

bool isExtern(string currentLine){
    regex reg ("(.extern)");
    smatch matches;

    while(std::regex_search(currentLine, matches, reg)){
        //std::cout << "Nadjena extern direktiva  " << "\n";
        return matches.ready();
    }
    return false;
}

void processExtern(string currentLine){
  regex reg ("([_a-zA-Z][_a-zA-Z0-9]*)");
  smatch matches;

  while(std::regex_search(currentLine, matches, reg)){
    // Get the first match
      string currVar = matches.str(1);
  
      // Eliminate the previous match and create
      // a new string to search
      currentLine = matches.suffix().str();
      if(currVar == "extern") continue;

      if(symbolTable.find(currVar) != symbolTable.end()) {
        cout<< "***ERROR!*** Symbol already defined!" << endl;
        exit(-1);
      }
      SymbolTableEntry newEntry = SymbolTableEntry(currVar,0,0,currentSymbolNumber++, true, false,{}, -1);
      symbolTable[currVar] = newEntry;
  }
}

bool isSection(string currentLine){
  regex reg ("(.section)");
    smatch matches;

    while(std::regex_search(currentLine, matches, reg)){
        // std::cout << "Nadjena .section direktiva  " << "\n";
        return matches.ready();
    }
    return false;
}

void processSection(string currentLine){

  //extract info from line
  regex reg ("([_a-zA-Z][_a-zA-Z0-9]*)");
  smatch matches;
  regex_search(currentLine, matches, reg);
  currentLine = matches.suffix().str();
  regex_search(currentLine, matches, reg);
  
  if(matches.size()!= 2) {
    cout<< "***ERROR!*** Too many params for section directive!" << endl;
    exit(-1);
  }
  string sectionName = matches.str(1);
  cout << matches.size() << endl;
  cout << sectionName << endl;

  //procces previous section
  currentSection = symbolTable.find(currentSectionName)->second;
  currentSection.size = locationCounter;

//adding new section
  // for sections symbolNumber will be equal to sectionNumber
  currentSectionNumber = currentSymbolNumber;
  cout << "Current section number " + currentSectionNumber <<endl;
  SymbolTableEntry newEntry = SymbolTableEntry(sectionName,currentSectionNumber,0,currentSymbolNumber++, false, true,{}, 0);

  //if section exists
  if(symbolTable.find(sectionName) != symbolTable.end()) {
        locationCounter = symbolTable.find(sectionName)->second.size;
  }else{
    symbolTable[sectionName] = newEntry;
    locationCounter = 0;
  }
}


void generateOutput(string output){
  printSymbolTable();
  // cout << "IDALJE NEMA IZLAZNOG FAJLA";
  // fstream outputFile;
  //  outputFile.open(output,ios::out);  // open a file to perform write operation using file object
  //  if(outputFile.is_open()) //checking whether the file is open
  //  {
  //     outputFile<<"Tutorials point \n";   //inserting text
  //     outputFile.close();    //close the file object
  //  }
};


//HELPER FUNCTIONS

void printSymbolTable(){

cout << setw(50)<< "Symbol table" << endl;
cout << setw(15) << "symbolName " 
    << setw(15) << "sectionNumber "  
    << setw(15) << "value " 
    << setw(15) << "symbolNumber "  
    << setw(15) << "isGlobal "  
    << setw(15) << "isDefined " 
    << setw(15) << "size "
    << endl;

 for(auto &itr: symbolTable){
  cout << setw(15) << itr.second.symbolName 
    << setw(15) << itr.second.sectionNumber
    << setw(15) << itr.second.value
    << setw(15) << itr.second.symbolNumber 
    << setw(15) << itr.second.isGlobal
    << setw(15) << itr.second.isDefined
    << setw(15) << itr.second.size
    << endl;
  }
}

string trimComments(string currentLine){

  return currentLine.substr(0, currentLine.find('#'));

}

const std::string WHITESPACE = " \n\r\t\f\v";

string ltrim(const string &s)
{
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == string::npos) ? "" : s.substr(start);
}
 
string rtrim(const string &s)
{
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == string::npos) ? "" : s.substr(0, end + 1);
}
 
string trim(const string &s) {
    return rtrim(ltrim(s));
}