#pragma once

using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <regex>
#include <list>

#include <iomanip>
#include <locale>

struct SymbolTableEntry{

  string symbolName;
  int sectionNumber = 0;
  int value = 0;
  int symbolNumber;
  bool isGlobal = false;
  bool isDefined = false;
  list<int> flink = {};
  int size = -1;

  SymbolTableEntry(string symbolName, int sectionNumber, int value, int symbolNumber, bool isGlobal, bool isDefined, list<int> flink, int size){
    this->symbolName = symbolName;
    this->sectionNumber = sectionNumber;
    this->value = value;
    this->symbolNumber = symbolNumber;
    this->isGlobal = isGlobal;
    this->isDefined = isDefined;
    this->flink = flink;
    this->size = size;
  }
  SymbolTableEntry(){};
  
};

struct SectionTableEntry{
  string sectionName;
  long startingAddress = 0;
  long size = 0;
  vector<char> code;

  SectionTableEntry(string sectionName){
    this->sectionName = sectionName;
  }
};

void setupAssembler();
void processLine(string currentLine);
string trimComments(string currentLine);
string trim(const string &s);
bool processDirective(string currentLine);
bool isGlobalDirective(string currentLine);
void processGlobalDirective(string currentLine);
bool isExtern(string currentLine);
void processExtern(string currentLine);
bool isSection(string currentLine);
void processSection(string currentLine);

void printSymbolTable();
void generateOutput(string outputFile);

